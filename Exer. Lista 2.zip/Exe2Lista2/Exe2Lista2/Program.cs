﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe2Lista2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;

            Console.Write("Digite o Primeiro Valor: ");
            v1 = Double.Parse(Console.ReadLine());

            Console.Write("Digite o Segundo Valor: ");
            v2 = Double.Parse(Console.ReadLine());

            if (v1 == v2)
                Console.WriteLine("Os Valores são iguais.");
            else
                if (v1 > v2)
                Console.WriteLine("O Primeiro Valor é maior.");
            else
                Console.WriteLine("O Segundo Valor é maior.");
        }
    }
    
}
