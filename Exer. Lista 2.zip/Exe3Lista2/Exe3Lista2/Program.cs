﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe3Lista2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            int c;

            Console.Write("Digite o 1º numero: ");
            a = int.Parse(Console.ReadLine());
            Console.Write("Digite o 2º numero: ");
            b = int.Parse(Console.ReadLine());
            Console.Write("Digite o 3º numero: ");
            c = int.Parse(Console.ReadLine());

            if (a == b)
                if (a == c)
                    Console.WriteLine("Os três valoes são iguais");
                else
                    if (a > c)
                    Console.WriteLine("O primeiro e o segundo valor são maiores");
                else
                    Console.WriteLine("O terceiro valor é maior");

               else
                if (a == c)
                if (a > b)
                    Console.WriteLine("O primeiro e o terceiro valor são maiores");
                else
                    Console.WriteLine("O segundo valor é maior");
            else
                if (b == c)
                if (b > a)
                    Console.WriteLine("O segundo e o terceiro valor são maiores");
                else
                    Console.WriteLine("O primeiro valor é maior");
               else
                 if (a > b)
                if (a > c)
                    Console.WriteLine("O primeiro valor é maior");
                else
                    Console.WriteLine("O terceiro valor é maior");
            else
                if (b > c)
                Console.WriteLine("O segundo valor maior");
            else
                Console.WriteLine("O terceiro valor é maior");
        }
    }
    
}
