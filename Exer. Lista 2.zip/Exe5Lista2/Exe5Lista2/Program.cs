﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe5Lista2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double h;

            Console.WriteLine("Digite o valor da Base. ");
            b = Double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da Altura. ");
            h = Double.Parse(Console.ReadLine());

            a = b * h;

            Console.WriteLine("O Seu terreno têm {0} metros", a);

            if (a > 100)
                Console.WriteLine("Terreno Grande.");
            else
                Console.WriteLine("Terreno Pequeno.");
        }
    }
}
